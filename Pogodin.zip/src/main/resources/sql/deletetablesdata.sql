delete from bus_application;
delete from busses;
delete from users;
